﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CORE.StatPlayerOnMap
{
    interface IStatPlayerOnMapRepository
    {
    }
}
