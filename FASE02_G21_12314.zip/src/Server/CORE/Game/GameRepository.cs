﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CORE.Game
{
    class GameRepository
    {
    }
}
