﻿using System;

namespace Teste
{
    public class Class1
    {
    }
}
