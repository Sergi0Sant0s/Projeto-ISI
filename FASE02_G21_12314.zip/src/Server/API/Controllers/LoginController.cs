﻿using DATA.Context;
using DATA.Jwt;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly MyContext _context;

        public LoginController(MyContext context)
        {
            _context = context;
        }

        // POST: Events
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Login>> Login(Login @login)
        {
            /*var user = _context..FirstOrDefault(e => e.UserName == @login.Username && e.PasswordHash == @login.Password);

            if (user != null)
                return Accepted("token");
            return BadRequest("User Name or Password not match");*/
            return BadRequest();
        }
    }
}
